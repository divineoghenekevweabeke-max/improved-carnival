import { useState } from 'react';
import { Plus } from 'lucide-react';
import { useCart } from '@/context/CartContext';
import type { Product } from '@/types';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';

interface ProductCardProps {
  product: Product;
  className?: string;
}

export function ProductCard({ product, className = '' }: ProductCardProps) {
  const { addToCart } = useCart();
  const [isOpen, setIsOpen] = useState(false);
  const [selectedSize, setSelectedSize] = useState<string>('M');

  const sizes = ['XS', 'S', 'M', 'L', 'XL'];

  const handleAddToCart = () => {
    addToCart(product, selectedSize);
    setIsOpen(false);
  };

  return (
    <>
      <div
        className={`bg-white shadow-[0_18px_40px_rgba(0,0,0,0.10)] overflow-hidden group cursor-pointer ${className}`}
        onClick={() => setIsOpen(true)}
      >
        <div className="relative h-[75%] overflow-hidden">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
        </div>
        <div className="p-5 flex justify-between items-end">
          <div>
            <h3 className="font-medium text-[#111111] text-lg">{product.name}</h3>
            <p className="text-[#6F6F6F] mt-1">${product.price}</p>
          </div>
          <button
            onClick={(e) => {
              e.stopPropagation();
              addToCart(product, selectedSize);
            }}
            className="w-10 h-10 bg-[#D93A3A] text-white flex items-center justify-center hover:bg-[#b82f2f] transition-colors"
          >
            <Plus className="w-5 h-5" />
          </button>
        </div>
      </div>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="bg-white max-w-2xl p-0 overflow-hidden">
          <div className="grid md:grid-cols-2">
            <div className="aspect-[3/4] bg-[#F6F6F2]">
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="p-8 flex flex-col justify-between">
              <div>
                <DialogHeader>
                  <DialogTitle className="text-2xl font-bold uppercase tracking-tight text-[#111111]">
                    {product.name}
                  </DialogTitle>
                </DialogHeader>
                <p className="text-2xl font-medium text-[#111111] mt-4">
                  ${product.price}
                </p>
                <p className="text-[#6F6F6F] mt-4 leading-relaxed">
                  {product.description || 'Crafted with premium materials for everyday comfort and style. Part of our sustainable collection.'}
                </p>
                
                <div className="mt-6">
                  <p className="text-sm uppercase tracking-wider text-[#6F6F6F] mb-3">
                    Select Size
                  </p>
                  <div className="flex gap-2">
                    {sizes.map((size) => (
                      <button
                        key={size}
                        onClick={() => setSelectedSize(size)}
                        className={`w-10 h-10 border text-sm font-medium transition-colors ${
                          selectedSize === size
                            ? 'border-[#111111] bg-[#111111] text-white'
                            : 'border-[#111111]/20 text-[#111111] hover:border-[#111111]'
                        }`}
                      >
                        {size}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
              
              <Button
                onClick={handleAddToCart}
                className="w-full bg-[#D93A3A] hover:bg-[#b82f2f] text-white uppercase tracking-wider text-sm font-semibold py-6 mt-8"
              >
                Add to Bag
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
