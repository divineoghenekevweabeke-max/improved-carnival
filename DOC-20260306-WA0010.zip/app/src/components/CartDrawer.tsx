import { X, Plus, Minus, ShoppingBag } from 'lucide-react';
import { useCart } from '@/context/CartContext';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';

export function CartDrawer() {
  const { items, isOpen, setIsOpen, removeFromCart, updateQuantity, totalPrice } = useCart();

  return (
    <Sheet open={isOpen} onOpenChange={setIsOpen}>
      <SheetContent side="right" className="bg-white w-full sm:w-[420px] flex flex-col">
        <SheetHeader className="pb-4">
          <SheetTitle className="text-xl font-bold uppercase tracking-tight text-[#111111]">
            Your Bag ({items.length})
          </SheetTitle>
        </SheetHeader>

        {items.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center gap-4">
            <ShoppingBag className="w-16 h-16 text-[#6F6F6F]" strokeWidth={1} />
            <p className="text-[#6F6F6F] text-center">Your bag is empty</p>
            <Button
              onClick={() => setIsOpen(false)}
              className="bg-[#D93A3A] hover:bg-[#b82f2f] text-white uppercase tracking-wider text-sm font-semibold px-8"
            >
              Continue Shopping
            </Button>
          </div>
        ) : (
          <>
            <div className="flex-1 overflow-auto py-4">
              <div className="space-y-6">
                {items.map((item) => (
                  <div key={item.id} className="flex gap-4">
                    <div className="w-24 h-32 bg-[#F6F6F2] overflow-hidden flex-shrink-0">
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1 flex flex-col justify-between">
                      <div>
                        <div className="flex justify-between items-start">
                          <h3 className="font-medium text-[#111111]">{item.name}</h3>
                          <button
                            onClick={() => removeFromCart(item.id)}
                            className="p-1 hover:opacity-70 transition-opacity"
                          >
                            <X className="w-4 h-4 text-[#6F6F6F]" />
                          </button>
                        </div>
                        {(item.size || item.color) && (
                          <p className="text-sm text-[#6F6F6F] mt-1">
                            {item.size && `Size: ${item.size}`}
                            {item.size && item.color && ' / '}
                            {item.color && `Color: ${item.color}`}
                          </p>
                        )}
                      </div>
                      <div className="flex justify-between items-center">
                        <div className="flex items-center gap-2 border border-[#111111]/20">
                          <button
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                            className="p-2 hover:bg-[#F6F6F2] transition-colors"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="w-8 text-center text-sm font-medium">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                            className="p-2 hover:bg-[#F6F6F2] transition-colors"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                        <span className="font-medium text-[#111111]">
                          ${item.price * item.quantity}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="border-t border-[#111111]/10 pt-4 space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-[#6F6F6F]">Subtotal</span>
                <span className="text-xl font-bold text-[#111111]">${totalPrice}</span>
              </div>
              <p className="text-xs text-[#6F6F6F]">
                Shipping and taxes calculated at checkout.
              </p>
              <Button
                className="w-full bg-[#D93A3A] hover:bg-[#b82f2f] text-white uppercase tracking-wider text-sm font-semibold py-6"
                onClick={() => {
                  setIsOpen(false);
                  window.location.href = '/checkout';
                }}
              >
                Proceed to Checkout
              </Button>
              <button
                onClick={() => setIsOpen(false)}
                className="w-full text-center text-sm text-[#6F6F6F] hover:text-[#111111] transition-colors uppercase tracking-wider"
              >
                Continue Shopping
              </button>
            </div>
          </>
        )}
      </SheetContent>
    </Sheet>
  );
}
