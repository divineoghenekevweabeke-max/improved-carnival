import { useState } from 'react';
import { ArrowLeft, CreditCard, Truck, Shield } from 'lucide-react';
import { useCart } from '@/context/CartContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';

export function Checkout() {
  const { items, totalPrice, clearCart } = useCart();
  const [step, setStep] = useState<'shipping' | 'payment' | 'confirmation'>('shipping');
  const [isProcessing, setIsProcessing] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (step === 'shipping') {
      setStep('payment');
    } else if (step === 'payment') {
      setIsProcessing(true);
      // Simulate payment processing
      await new Promise(resolve => setTimeout(resolve, 2000));
      setIsProcessing(false);
      setStep('confirmation');
      clearCart();
      toast.success('Order placed successfully!');
    }
  };

  if (items.length === 0 && step !== 'confirmation') {
    return (
      <div className="min-h-screen bg-[#F6F6F2] flex flex-col items-center justify-center p-6">
        <div className="text-center">
          <h1 className="text-2xl font-bold uppercase tracking-tight text-[#111111] mb-4">
            Your bag is empty
          </h1>
          <p className="text-[#6F6F6F] mb-8">Add some items to proceed with checkout.</p>
          <Button
            onClick={() => window.location.href = '/'}
            className="bg-[#D93A3A] hover:bg-[#b82f2f] text-white uppercase tracking-wider text-sm font-semibold px-8"
          >
            Continue Shopping
          </Button>
        </div>
      </div>
    );
  }

  if (step === 'confirmation') {
    return (
      <div className="min-h-screen bg-[#F6F6F2] flex flex-col items-center justify-center p-6">
        <div className="text-center max-w-md">
          <div className="w-16 h-16 bg-[#D93A3A] rounded-full flex items-center justify-center mx-auto mb-6">
            <Shield className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-black uppercase tracking-tight text-[#111111] mb-4">
            Thank You!
          </h1>
          <p className="text-[#6F6F6F] mb-2">
            Your order has been placed successfully.
          </p>
          <p className="text-[#6F6F6F] mb-8">
            Order confirmation sent to your email.
          </p>
          <Button
            onClick={() => window.location.href = '/'}
            className="bg-[#D93A3A] hover:bg-[#b82f2f] text-white uppercase tracking-wider text-sm font-semibold px-8"
          >
            Continue Shopping
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F6F6F2]">
      {/* Header */}
      <header className="bg-white border-b border-[#111111]/10 px-6 py-4">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <button
            onClick={() => step === 'payment' ? setStep('shipping') : window.history.back()}
            className="flex items-center gap-2 text-[#111111] hover:text-[#D93A3A] transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="text-sm uppercase tracking-wider font-medium">
              {step === 'payment' ? 'Back to Shipping' : 'Continue Shopping'}
            </span>
          </button>
          <h1 className="text-lg font-bold uppercase tracking-[0.2em] text-[#111111]">
            Boutique
          </h1>
          <div className="w-24" />
        </div>
      </header>

      <div className="max-w-6xl mx-auto p-6 py-12">
        <div className="grid lg:grid-cols-2 gap-12">
          {/* Left Column - Form */}
          <div>
            {/* Progress */}
            <div className="flex items-center gap-4 mb-8">
              <div className={`flex items-center gap-2 ${step === 'shipping' ? 'text-[#D93A3A]' : 'text-[#111111]'}`}>
                <Truck className="w-4 h-4" />
                <span className="text-sm uppercase tracking-wider font-medium">Shipping</span>
              </div>
              <div className="flex-1 h-px bg-[#111111]/20" />
              <div className={`flex items-center gap-2 ${step === 'payment' ? 'text-[#D93A3A]' : 'text-[#6F6F6F]'}`}>
                <CreditCard className="w-4 h-4" />
                <span className="text-sm uppercase tracking-wider font-medium">Payment</span>
              </div>
            </div>

            <form onSubmit={handleSubmit}>
              {step === 'shipping' ? (
                <div className="space-y-6">
                  <h2 className="text-xl font-bold uppercase tracking-tight text-[#111111]">
                    Shipping Information
                  </h2>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="firstName" className="text-sm uppercase tracking-wider text-[#6F6F6F]">
                        First Name
                      </Label>
                      <Input id="firstName" required className="h-12 border-[#111111]/20 focus:border-[#D93A3A]" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="lastName" className="text-sm uppercase tracking-wider text-[#6F6F6F]">
                        Last Name
                      </Label>
                      <Input id="lastName" required className="h-12 border-[#111111]/20 focus:border-[#D93A3A]" />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-sm uppercase tracking-wider text-[#6F6F6F]">
                      Email
                    </Label>
                    <Input id="email" type="email" required className="h-12 border-[#111111]/20 focus:border-[#D93A3A]" />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="address" className="text-sm uppercase tracking-wider text-[#6F6F6F]">
                      Address
                    </Label>
                    <Input id="address" required className="h-12 border-[#111111]/20 focus:border-[#D93A3A]" />
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="city" className="text-sm uppercase tracking-wider text-[#6F6F6F]">
                        City
                      </Label>
                      <Input id="city" required className="h-12 border-[#111111]/20 focus:border-[#D93A3A]" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="state" className="text-sm uppercase tracking-wider text-[#6F6F6F]">
                        State
                      </Label>
                      <Input id="state" required className="h-12 border-[#111111]/20 focus:border-[#D93A3A]" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="zip" className="text-sm uppercase tracking-wider text-[#6F6F6F]">
                        ZIP
                      </Label>
                      <Input id="zip" required className="h-12 border-[#111111]/20 focus:border-[#D93A3A]" />
                    </div>
                  </div>
                </div>
              ) : (
                <div className="space-y-6">
                  <h2 className="text-xl font-bold uppercase tracking-tight text-[#111111]">
                    Payment Information
                  </h2>
                  
                  <div className="space-y-2">
                    <Label htmlFor="cardNumber" className="text-sm uppercase tracking-wider text-[#6F6F6F]">
                      Card Number
                    </Label>
                    <Input id="cardNumber" placeholder="1234 5678 9012 3456" required className="h-12 border-[#111111]/20 focus:border-[#D93A3A]" />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="expiry" className="text-sm uppercase tracking-wider text-[#6F6F6F]">
                        Expiry Date
                      </Label>
                      <Input id="expiry" placeholder="MM/YY" required className="h-12 border-[#111111]/20 focus:border-[#D93A3A]" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="cvv" className="text-sm uppercase tracking-wider text-[#6F6F6F]">
                        CVV
                      </Label>
                      <Input id="cvv" placeholder="123" required className="h-12 border-[#111111]/20 focus:border-[#D93A3A]" />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="nameOnCard" className="text-sm uppercase tracking-wider text-[#6F6F6F]">
                      Name on Card
                    </Label>
                    <Input id="nameOnCard" required className="h-12 border-[#111111]/20 focus:border-[#D93A3A]" />
                  </div>
                </div>
              )}

              <Button
                type="submit"
                disabled={isProcessing}
                className="w-full mt-8 bg-[#D93A3A] hover:bg-[#b82f2f] text-white uppercase tracking-wider text-sm font-semibold py-6"
              >
                {isProcessing ? 'Processing...' : step === 'shipping' ? 'Continue to Payment' : 'Place Order'}
              </Button>
            </form>
          </div>

          {/* Right Column - Order Summary */}
          <div className="bg-white p-8 h-fit">
            <h2 className="text-xl font-bold uppercase tracking-tight text-[#111111] mb-6">
              Order Summary
            </h2>
            
            <div className="space-y-4 mb-6">
              {items.map((item) => (
                <div key={item.id} className="flex gap-4">
                  <div className="w-20 h-24 bg-[#F6F6F2] overflow-hidden flex-shrink-0">
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-medium text-[#111111]">{item.name}</h3>
                    {item.size && (
                      <p className="text-sm text-[#6F6F6F]">Size: {item.size}</p>
                    )}
                    <p className="text-sm text-[#6F6F6F]">Qty: {item.quantity}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-[#111111]">${item.price * item.quantity}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="border-t border-[#111111]/10 pt-6 space-y-3">
              <div className="flex justify-between text-[#6F6F6F]">
                <span>Subtotal</span>
                <span>${totalPrice}</span>
              </div>
              <div className="flex justify-between text-[#6F6F6F]">
                <span>Shipping</span>
                <span>Free</span>
              </div>
              <div className="flex justify-between text-[#6F6F6F]">
                <span>Tax</span>
                <span>Calculated at checkout</span>
              </div>
              <div className="flex justify-between text-xl font-bold text-[#111111] pt-3 border-t border-[#111111]/10">
                <span>Total</span>
                <span>${totalPrice}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
