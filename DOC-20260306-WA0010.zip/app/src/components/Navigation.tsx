import { useState, useEffect } from 'react';
import { Menu, Search, ShoppingBag } from 'lucide-react';
import { useCart } from '@/context/CartContext';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';

export function Navigation() {
  const { totalItems, toggleCart } = useCart();
  const [isScrolled, setIsScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 100);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled
            ? 'bg-[#F6F6F2]/90 backdrop-blur-sm'
            : 'bg-transparent'
        }`}
      >
        <div className="flex items-center justify-between px-6 py-4">
          {/* Menu Button */}
          <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
            <SheetTrigger asChild>
              <button className="p-2 hover:opacity-70 transition-opacity">
                <Menu className="w-5 h-5 text-[#111111]" strokeWidth={1.5} />
              </button>
            </SheetTrigger>
            <SheetContent side="left" className="bg-[#F6F6F2] border-r border-[#111111]/10 w-[300px]">
              <div className="flex flex-col gap-8 mt-12">
                <a href="#" className="text-2xl font-bold uppercase tracking-tight text-[#111111] hover:text-[#D93A3A] transition-colors">
                  New Arrivals
                </a>
                <a href="#" className="text-2xl font-bold uppercase tracking-tight text-[#111111] hover:text-[#D93A3A] transition-colors">
                  Essentials
                </a>
                <a href="#" className="text-2xl font-bold uppercase tracking-tight text-[#111111] hover:text-[#D93A3A] transition-colors">
                  Curated Sets
                </a>
                <a href="#" className="text-2xl font-bold uppercase tracking-tight text-[#111111] hover:text-[#D93A3A] transition-colors">
                  Trending
                </a>
                <a href="#" className="text-2xl font-bold uppercase tracking-tight text-[#111111] hover:text-[#D93A3A] transition-colors">
                  Accessories
                </a>
                <a href="#" className="text-2xl font-bold uppercase tracking-tight text-[#111111] hover:text-[#D93A3A] transition-colors">
                  Sale
                </a>
              </div>
            </SheetContent>
          </Sheet>

          {/* Logo */}
          <a href="/" className="absolute left-1/2 -translate-x-1/2">
            <h1 className="text-lg font-bold uppercase tracking-[0.2em] text-[#111111]">
              Boutique
            </h1>
          </a>

          {/* Right Actions */}
          <div className="flex items-center gap-4">
            <button className="p-2 hover:opacity-70 transition-opacity">
              <Search className="w-5 h-5 text-[#111111]" strokeWidth={1.5} />
            </button>
            <button
              onClick={toggleCart}
              className="p-2 hover:opacity-70 transition-opacity relative"
            >
              <ShoppingBag className="w-5 h-5 text-[#111111]" strokeWidth={1.5} />
              {totalItems > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-[#D93A3A] text-white text-xs font-medium rounded-full flex items-center justify-center">
                  {totalItems}
                </span>
              )}
            </button>
          </div>
        </div>
      </nav>
    </>
  );
}
