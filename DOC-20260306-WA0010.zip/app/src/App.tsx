import { useEffect, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { CartProvider } from '@/context/CartContext';
import { Navigation } from '@/components/Navigation';
import { CartDrawer } from '@/components/CartDrawer';
import { Checkout } from '@/components/Checkout';
import { HeroSection } from '@/sections/HeroSection';
import { EssentialsSection } from '@/sections/EssentialsSection';
import { CuratedSection } from '@/sections/CuratedSection';
import { TrendingSection } from '@/sections/TrendingSection';
import { FeedSection } from '@/sections/FeedSection';
import { StyleSection } from '@/sections/StyleSection';
import { CompleteSection } from '@/sections/CompleteSection';
import { CategoriesSection } from '@/sections/CategoriesSection';
import { FooterSection } from '@/sections/FooterSection';
import { Toaster } from '@/components/ui/sonner';
import './App.css';

gsap.registerPlugin(ScrollTrigger);

function App() {
  const [isCheckout, setIsCheckout] = useState(false);

  useEffect(() => {
    // Check if we're on the checkout page
    if (window.location.pathname === '/checkout') {
      setIsCheckout(true);
      return;
    }

    // Wait for all ScrollTriggers to be created
    const timer = setTimeout(() => {
      const pinned = ScrollTrigger.getAll()
        .filter(st => st.vars.pin)
        .sort((a, b) => a.start - b.start);
      
      const maxScroll = ScrollTrigger.maxScroll(window);
      
      if (!maxScroll || pinned.length === 0) return;

      // Build ranges and snap targets from pinned sections
      const pinnedRanges = pinned.map(st => ({
        start: st.start / maxScroll,
        end: (st.end ?? st.start) / maxScroll,
        center: (st.start + ((st.end ?? st.start) - st.start) * 0.5) / maxScroll,
      }));

      // Create global snap
      ScrollTrigger.create({
        snap: {
          snapTo: (value: number) => {
            // Check if within any pinned range (with buffer)
            const inPinned = pinnedRanges.some(
              r => value >= r.start - 0.02 && value <= r.end + 0.02
            );
            
            if (!inPinned) return value; // Flowing section: free scroll

            // Find nearest pinned center
            const target = pinnedRanges.reduce((closest, r) =>
              Math.abs(r.center - value) < Math.abs(closest - value) ? r.center : closest,
              pinnedRanges[0]?.center ?? 0
            );
            
            return target;
          },
          duration: { min: 0.15, max: 0.35 },
          delay: 0,
          ease: 'power2.out',
        }
      });
    }, 100);

    return () => {
      clearTimeout(timer);
      ScrollTrigger.getAll().forEach(st => st.kill());
    };
  }, []);

  if (isCheckout) {
    return (
      <CartProvider>
        <Checkout />
        <Toaster position="top-center" />
      </CartProvider>
    );
  }

  return (
    <CartProvider>
      <div className="relative">
        {/* Global Grain Overlay */}
        <div 
          className="fixed inset-0 pointer-events-none z-[100] opacity-[0.06]"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`,
            mixBlendMode: 'multiply',
          }}
        />

        <Navigation />
        <CartDrawer />
        
        <main className="relative">
          <HeroSection />
          <EssentialsSection />
          <CuratedSection />
          <TrendingSection />
          <FeedSection />
          <StyleSection />
          <CompleteSection />
          <CategoriesSection />
          <FooterSection />
        </main>

        <Toaster position="top-center" />
      </div>
    </CartProvider>
  );
}

export default App;
