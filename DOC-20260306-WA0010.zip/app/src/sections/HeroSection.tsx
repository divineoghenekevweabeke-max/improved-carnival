import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ProductCard } from '@/components/ProductCard';
import type { Product } from '@/types';

gsap.registerPlugin(ScrollTrigger);

const featuredProduct: Product = {
  id: 'relaxed-blazer',
  name: 'Relaxed Blazer',
  price: 129,
  image: '/images/hero_card_blazer.jpg',
  category: 'Outerwear',
  description: 'A timeless piece crafted from premium linen blend. Perfect for layering through every season.',
};

export function HeroSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const bgRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const subheadRef = useRef<HTMLDivElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const bg = bgRef.current;
    const headline = headlineRef.current;
    const subhead = subheadRef.current;
    const cta = ctaRef.current;
    const card = cardRef.current;

    if (!section || !bg || !headline || !subhead || !cta || !card) return;

    const ctx = gsap.context(() => {
      // Initial load animation
      const loadTl = gsap.timeline();
      
      loadTl
        .fromTo(bg, 
          { opacity: 0, scale: 1.06 },
          { opacity: 1, scale: 1, duration: 1.2, ease: 'power3.out' }
        )
        .fromTo(headline.children,
          { y: 40, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.8, stagger: 0.08, ease: 'power3.out' },
          '-=0.8'
        )
        .fromTo([subhead, cta],
          { y: 30, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.7, stagger: 0.1, ease: 'power3.out' },
          '-=0.5'
        )
        .fromTo(card,
          { x: '40vw', opacity: 0 },
          { x: 0, opacity: 1, duration: 0.9, ease: 'power3.out' },
          '-=0.7'
        );

      // Scroll-driven exit animation
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
          anticipatePin: 1,
          onLeaveBack: () => {
            // Reset all elements when scrolling back to top
            gsap.set([headline.children, subhead, cta], { x: 0, opacity: 1 });
            gsap.set(card, { x: 0, opacity: 1 });
            gsap.set(bg, { y: 0 });
          }
        }
      });

      // EXIT phase (70% - 100%)
      scrollTl
        .fromTo(headline.children,
          { x: 0, opacity: 1 },
          { x: '-18vw', opacity: 0, ease: 'power2.in', stagger: 0.02 },
          0.7
        )
        .fromTo([subhead, cta],
          { x: 0, opacity: 1 },
          { x: '-14vw', opacity: 0, ease: 'power2.in', stagger: 0.02 },
          0.72
        )
        .fromTo(card,
          { x: 0, opacity: 1 },
          { x: '18vw', opacity: 0, ease: 'power2.in' },
          0.7
        )
        .fromTo(bg,
          { y: 0 },
          { y: '-6vh', ease: 'none' },
          0.7
        );

    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative w-full h-screen overflow-hidden z-10"
    >
      {/* Background Image */}
      <div
        ref={bgRef}
        className="absolute inset-0 w-full h-full"
      >
        <img
          src="/images/hero_bg.jpg"
          alt="Fashion model"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#F6F6F2]/80 via-[#F6F6F2]/40 to-transparent" />
      </div>

      {/* Content */}
      <div className="relative h-full flex items-center">
        {/* Left Text Content */}
        <div className="pl-[6vw] w-[52vw]">
          <div ref={headlineRef} className="space-y-0">
            <h1 className="text-[clamp(44px,6vw,96px)] font-black uppercase tracking-tight text-[#111111] leading-[0.95]">
              NEW
            </h1>
            <h1 className="text-[clamp(44px,6vw,96px)] font-black uppercase tracking-tight text-[#111111] leading-[0.95]">
              IN
            </h1>
            <h1 className="text-[clamp(44px,6vw,96px)] font-black uppercase tracking-tight text-[#111111] leading-[0.95]">
              NOW
            </h1>
          </div>

          <p
            ref={subheadRef}
            className="mt-8 text-lg md:text-xl text-[#111111] max-w-[34vw] leading-relaxed"
          >
            Weekly drops. Clean silhouettes. Built for real days.
          </p>

          <div ref={ctaRef} className="mt-8">
            <button className="bg-[#D93A3A] hover:bg-[#b82f2f] text-white uppercase tracking-wider text-sm font-semibold px-8 py-4 transition-colors">
              Shop New Arrivals
            </button>
          </div>
        </div>

        {/* Right Product Card */}
        <div
          ref={cardRef}
          className="absolute right-[6vw] top-[18vh] w-[32vw] h-[62vh]"
        >
          <ProductCard product={featuredProduct} className="h-full" />
        </div>
      </div>
    </section>
  );
}
