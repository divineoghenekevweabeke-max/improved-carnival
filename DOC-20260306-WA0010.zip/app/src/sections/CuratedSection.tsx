import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ProductCard } from '@/components/ProductCard';
import type { Product } from '@/types';

gsap.registerPlugin(ScrollTrigger);

const featuredProduct: Product = {
  id: 'linen-set',
  name: 'Linen Set',
  price: 149,
  image: '/images/curated_card_linen.jpg',
  category: 'Sets',
  description: 'A matching set designed for effortless elegance. Breathable linen for all-day comfort.',
};

export function CuratedSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const bgRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const bodyRef = useRef<HTMLDivElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const cardBack1Ref = useRef<HTMLDivElement>(null);
  const cardBack2Ref = useRef<HTMLDivElement>(null);
  const cardFrontRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const bg = bgRef.current;
    const headline = headlineRef.current;
    const body = bodyRef.current;
    const cta = ctaRef.current;
    const cardBack1 = cardBack1Ref.current;
    const cardBack2 = cardBack2Ref.current;
    const cardFront = cardFrontRef.current;

    if (!section || !bg || !headline || !body || !cta || !cardBack1 || !cardBack2 || !cardFront) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
          anticipatePin: 1,
        }
      });

      // ENTRANCE (0% - 30%)
      scrollTl
        .fromTo(bg,
          { scale: 1.06, opacity: 0.7 },
          { scale: 1, opacity: 1, ease: 'none' },
          0
        )
        .fromTo(headline.children,
          { y: '16vh', opacity: 0 },
          { y: 0, opacity: 1, ease: 'none', stagger: 0.02 },
          0
        )
        .fromTo([body, cta],
          { y: '10vh', opacity: 0 },
          { y: 0, opacity: 1, ease: 'none', stagger: 0.02 },
          0.1
        )
        .fromTo(cardBack1,
          { x: '50vw', opacity: 0 },
          { x: 0, opacity: 1, ease: 'none' },
          0
        )
        .fromTo(cardBack2,
          { x: '60vw', opacity: 0 },
          { x: 0, opacity: 1, ease: 'none' },
          0.05
        )
        .fromTo(cardFront,
          { x: '55vw', rotate: 3, opacity: 0 },
          { x: 0, rotate: 0, opacity: 1, ease: 'none' },
          0.1
        );

      // SETTLE (30% - 70%) - hold position

      // EXIT (70% - 100%)
      scrollTl
        .fromTo(headline.children,
          { x: 0, opacity: 1 },
          { x: '-12vw', opacity: 0, ease: 'power2.in', stagger: 0.02 },
          0.7
        )
        .fromTo([body, cta],
          { x: 0, opacity: 1 },
          { x: '-10vw', opacity: 0, ease: 'power2.in', stagger: 0.02 },
          0.72
        )
        .fromTo(cardFront,
          { x: 0, opacity: 1 },
          { x: '18vw', opacity: 0, ease: 'power2.in' },
          0.7
        )
        .fromTo([cardBack1, cardBack2],
          { x: 0, opacity: 1 },
          { x: '10vw', opacity: 0, ease: 'power2.in', stagger: 0.02 },
          0.72
        );

    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative w-full h-screen overflow-hidden z-30"
    >
      {/* Background Image */}
      <div
        ref={bgRef}
        className="absolute inset-0 w-full h-full"
      >
        <img
          src="/images/curated_bg.jpg"
          alt="Fashion model in linen"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#F6F6F2]/80 via-[#F6F6F2]/40 to-transparent" />
      </div>

      {/* Content */}
      <div className="relative h-full flex items-center">
        {/* Left Text Content */}
        <div className="pl-[6vw] w-[46vw]">
          <div ref={headlineRef} className="space-y-0">
            <h1 className="text-[clamp(44px,6vw,96px)] font-black uppercase tracking-tight text-[#111111] leading-[0.95]">
              CURATED
            </h1>
            <h1 className="text-[clamp(44px,6vw,96px)] font-black uppercase tracking-tight text-[#111111] leading-[0.95]">
              SETS
            </h1>
          </div>

          <p
            ref={bodyRef}
            className="mt-8 text-lg md:text-xl text-[#111111] max-w-[32vw] leading-relaxed"
          >
            Pre-styled looks. Mix, match, and make them yours.
          </p>

          <div ref={ctaRef} className="mt-8">
            <button className="bg-[#D93A3A] hover:bg-[#b82f2f] text-white uppercase tracking-wider text-sm font-semibold px-8 py-4 transition-colors">
              Explore Sets
            </button>
          </div>
        </div>

        {/* Right Stacked Cards */}
        <div className="absolute right-[6vw] top-[18vh] w-[32vw] h-[62vh]">
          {/* Back Card 2 */}
          <div
            ref={cardBack2Ref}
            className="absolute left-[8vw] -top-[4vh] w-[24vw] h-[62vh] bg-[#DDD]"
          />
          {/* Back Card 1 */}
          <div
            ref={cardBack1Ref}
            className="absolute left-[4vw] -top-[2vh] w-[28vw] h-[62vh] bg-[#E9E9E3]"
          />
          {/* Front Card */}
          <div
            ref={cardFrontRef}
            className="absolute left-0 top-0 w-[32vw] h-[62vh]"
          >
            <ProductCard product={featuredProduct} className="h-full" />
          </div>
        </div>
      </div>
    </section>
  );
}
