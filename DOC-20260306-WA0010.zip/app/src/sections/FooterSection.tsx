import { useState, useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Instagram, Mail, Clock, Truck, Ruler } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';

gsap.registerPlugin(ScrollTrigger);

export function FooterSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const leftRef = useRef<HTMLDivElement>(null);
  const rightRef = useRef<HTMLDivElement>(null);
  const [email, setEmail] = useState('');

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const left = leftRef.current;
    const right = rightRef.current;

    if (!section || !left || !right) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(left,
        { y: 40, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: left,
            start: 'top 85%',
            toggleActions: 'play none none reverse',
          }
        }
      );

      gsap.fromTo(right,
        { y: 40, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          delay: 0.1,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: right,
            start: 'top 85%',
            toggleActions: 'play none none reverse',
          }
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      toast.success('Thank you for subscribing!');
      setEmail('');
    }
  };

  return (
    <footer
      ref={sectionRef}
      className="relative bg-[#111111] text-[#F6F6F2] py-20 z-[90]"
    >
      <div className="px-[6vw]">
        <div className="grid md:grid-cols-2 gap-16">
          {/* Left Column - Newsletter */}
          <div ref={leftRef}>
            <h2 className="text-[clamp(28px,3vw,48px)] font-black uppercase tracking-tight leading-[0.95]">
              STAY IN
            </h2>
            <h2 className="text-[clamp(28px,3vw,48px)] font-black uppercase tracking-tight leading-[0.95]">
              THE LOOP
            </h2>
            <p className="mt-6 text-lg text-[#F6F6F2]/70 leading-relaxed max-w-md">
              New drops, restocks, and style notes—once a week.
            </p>

            <form onSubmit={handleSubscribe} className="mt-8 flex gap-3">
              <Input
                type="email"
                placeholder="Email address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="flex-1 bg-transparent border-[#F6F6F2]/30 text-[#F6F6F2] placeholder:text-[#F6F6F2]/50 focus:border-[#D93A3A] h-12"
              />
              <Button
                type="submit"
                className="bg-[#D93A3A] hover:bg-[#b82f2f] text-white uppercase tracking-wider text-sm font-semibold px-6 h-12"
              >
                Subscribe
              </Button>
            </form>
            <p className="mt-3 text-xs text-[#F6F6F2]/50">
              No spam. Unsubscribe anytime.
            </p>
          </div>

          {/* Right Column - Customer Care */}
          <div ref={rightRef}>
            <h3 className="text-lg font-semibold uppercase tracking-wider mb-6">
              Customer Care
            </h3>
            <div className="space-y-4">
              <div className="flex items-center gap-3 text-[#F6F6F2]/70">
                <Mail className="w-4 h-4" />
                <span>hello@boutique.studio</span>
              </div>
              <div className="flex items-center gap-3 text-[#F6F6F2]/70">
                <Clock className="w-4 h-4" />
                <span>Mon–Fri, 9am–6pm</span>
              </div>
              <div className="flex items-center gap-3 text-[#F6F6F2]/70">
                <Truck className="w-4 h-4" />
                <span>Shipping & Returns</span>
              </div>
              <div className="flex items-center gap-3 text-[#F6F6F2]/70">
                <Ruler className="w-4 h-4" />
                <span>Size Guide</span>
              </div>
            </div>

            <div className="mt-8">
              <h3 className="text-lg font-semibold uppercase tracking-wider mb-4">
                Follow Us
              </h3>
              <div className="flex gap-4">
                <a
                  href="#"
                  className="w-10 h-10 border border-[#F6F6F2]/30 flex items-center justify-center hover:border-[#D93A3A] hover:text-[#D93A3A] transition-colors"
                >
                  <Instagram className="w-5 h-5" />
                </a>
                <a
                  href="#"
                  className="w-10 h-10 border border-[#F6F6F2]/30 flex items-center justify-center hover:border-[#D93A3A] hover:text-[#D93A3A] transition-colors"
                >
                  <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                    <circle cx="12" cy="12" r="10" />
                    <path d="M12 8v8M8 12h8" />
                  </svg>
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-16 pt-8 border-t border-[#F6F6F2]/10 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-[#F6F6F2]/50">
            © 2026 Boutique. All rights reserved.
          </p>
          <div className="flex gap-6">
            <a href="#" className="text-sm text-[#F6F6F2]/50 hover:text-[#F6F6F2] transition-colors">
              Privacy Policy
            </a>
            <a href="#" className="text-sm text-[#F6F6F2]/50 hover:text-[#F6F6F2] transition-colors">
              Terms of Service
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
