import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import type { Category } from '@/types';

gsap.registerPlugin(ScrollTrigger);

const categories: Category[] = [
  { id: 'outerwear', name: 'Outerwear', image: '/images/category_outerwear.jpg' },
  { id: 'tops', name: 'Tops', image: '/images/category_tops.jpg' },
  { id: 'bottoms', name: 'Bottoms', image: '/images/category_bottoms.jpg' },
  { id: 'dresses', name: 'Dresses', image: '/images/category_dresses.jpg' },
  { id: 'accessories', name: 'Accessories', image: '/images/category_accessories.jpg' },
  { id: 'sale', name: 'Sale', image: '/images/category_sale.jpg' },
];

export function CategoriesSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const gridRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const headline = headlineRef.current;
    const grid = gridRef.current;

    if (!section || !headline || !grid) return;

    const ctx = gsap.context(() => {
      // Headline animation
      gsap.fromTo(headline,
        { y: 40, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: headline,
            start: 'top 80%',
            end: 'top 55%',
            scrub: 1,
          }
        }
      );

      // Grid items animation
      const gridItems = grid.children;
      gsap.fromTo(gridItems,
        { y: 60, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          stagger: 0.1,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: grid,
            start: 'top 80%',
            end: 'top 40%',
            scrub: 1,
          }
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative bg-[#F6F6F2] py-20 z-[80]"
    >
      <div className="px-[6vw]">
        <div className="flex flex-col lg:flex-row gap-12">
          {/* Left Text Content */}
          <div ref={headlineRef} className="lg:w-[34vw] lg:sticky lg:top-24 lg:self-start">
            <h2 className="text-[clamp(32px,4vw,64px)] font-black uppercase tracking-tight text-[#111111] leading-[0.95]">
              BROWSE
            </h2>
            <h2 className="text-[clamp(32px,4vw,64px)] font-black uppercase tracking-tight text-[#111111] leading-[0.95]">
              CATEGORIES
            </h2>
            <p className="mt-6 text-lg text-[#111111] leading-relaxed max-w-[30vw]">
              Jump to what you need. Filter by fit, color, and price.
            </p>
            <button className="mt-8 bg-[#D93A3A] hover:bg-[#b82f2f] text-white uppercase tracking-wider text-sm font-semibold px-8 py-4 transition-colors">
              Shop All
            </button>
          </div>

          {/* Right Category Grid */}
          <div
            ref={gridRef}
            className="lg:ml-auto grid grid-cols-2 gap-6 lg:gap-8"
          >
            {categories.map((category) => (
              <div
                key={category.id}
                className="group relative w-full lg:w-[22vw] h-[28vh] overflow-hidden cursor-pointer"
              >
                <img
                  src={category.image}
                  alt={category.name}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute bottom-0 left-0 right-0 p-4">
                  <div className="inline-block bg-white/85 px-4 py-2">
                    <span className="text-sm font-semibold uppercase tracking-wider text-[#111111]">
                      {category.name}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
