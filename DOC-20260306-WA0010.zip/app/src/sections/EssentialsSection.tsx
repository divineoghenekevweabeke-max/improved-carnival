import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ProductCard } from '@/components/ProductCard';
import type { Product } from '@/types';

gsap.registerPlugin(ScrollTrigger);

const featuredProduct: Product = {
  id: 'canvas-tote',
  name: 'Canvas Tote',
  price: 59,
  image: '/images/essentials_card_tote.jpg',
  category: 'Accessories',
  description: 'Spacious, durable, and effortlessly chic. Made from organic cotton canvas.',
};

export function EssentialsSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const bgRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const bodyRef = useRef<HTMLDivElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const bg = bgRef.current;
    const headline = headlineRef.current;
    const body = bodyRef.current;
    const cta = ctaRef.current;
    const card = cardRef.current;

    if (!section || !bg || !headline || !body || !cta || !card) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
          anticipatePin: 1,
        }
      });

      // ENTRANCE (0% - 30%)
      scrollTl
        .fromTo(bg,
          { x: '8vw', scale: 1.08, opacity: 0.6 },
          { x: 0, scale: 1, opacity: 1, ease: 'none' },
          0
        )
        .fromTo(headline.children,
          { y: '18vh', opacity: 0 },
          { y: 0, opacity: 1, ease: 'none', stagger: 0.02 },
          0
        )
        .fromTo([body, cta],
          { y: '10vh', opacity: 0 },
          { y: 0, opacity: 1, ease: 'none', stagger: 0.02 },
          0.1
        )
        .fromTo(card,
          { x: '45vw', rotate: 2, opacity: 0 },
          { x: 0, rotate: 0, opacity: 1, ease: 'none' },
          0
        );

      // SETTLE (30% - 70%) - hold position

      // EXIT (70% - 100%)
      scrollTl
        .fromTo(headline.children,
          { x: 0, opacity: 1 },
          { x: '-14vw', opacity: 0, ease: 'power2.in', stagger: 0.02 },
          0.7
        )
        .fromTo([body, cta],
          { y: 0, opacity: 1 },
          { y: '-6vh', opacity: 0, ease: 'power2.in', stagger: 0.02 },
          0.72
        )
        .fromTo(card,
          { x: 0, opacity: 1 },
          { x: '16vw', opacity: 0, ease: 'power2.in' },
          0.7
        );

    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative w-full h-screen overflow-hidden z-20"
    >
      {/* Background Image */}
      <div
        ref={bgRef}
        className="absolute inset-0 w-full h-full"
      >
        <img
          src="/images/essentials_bg.jpg"
          alt="Fashion model with tote"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#F6F6F2]/80 via-[#F6F6F2]/40 to-transparent" />
      </div>

      {/* Content */}
      <div className="relative h-full flex items-center">
        {/* Left Text Content */}
        <div className="pl-[6vw] w-[46vw]">
          <div ref={headlineRef} className="space-y-0">
            <h1 className="text-[clamp(44px,6vw,96px)] font-black uppercase tracking-tight text-[#111111] leading-[0.95]">
              EVERYDAY
            </h1>
            <h1 className="text-[clamp(44px,6vw,96px)] font-black uppercase tracking-tight text-[#111111] leading-[0.95]">
              ESSENTIALS
            </h1>
          </div>

          <p
            ref={bodyRef}
            className="mt-8 text-lg md:text-xl text-[#111111] max-w-[30vw] leading-relaxed"
          >
            Easy fits that move with you. Soft fabrics. Clean cuts.
          </p>

          <div ref={ctaRef} className="mt-8">
            <button className="bg-[#D93A3A] hover:bg-[#b82f2f] text-white uppercase tracking-wider text-sm font-semibold px-8 py-4 transition-colors">
              Shop Essentials
            </button>
          </div>
        </div>

        {/* Right Product Card */}
        <div
          ref={cardRef}
          className="absolute right-[6vw] top-[18vh] w-[32vw] h-[62vh]"
        >
          <ProductCard product={featuredProduct} className="h-full" />
        </div>
      </div>
    </section>
  );
}
